/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
// #include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
SPI_HandleTypeDef hspi1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */
// ---------------- ICM-42688-P register map (Bank 0) ----------------
#define ICM_REG_DEVICE_CONFIG      0x11
#define ICM_REG_TEMP_DATA1         0x1D
#define ICM_REG_ACCEL_DATA_X1      0x1F
#define ICM_REG_GYRO_DATA_X1       0x25
#define ICM_REG_INTF_CONFIG0       0x4C
#define ICM_REG_INTF_CONFIG1       0x4D
#define ICM_REG_PWR_MGMT0          0x4E
#define ICM_REG_GYRO_CONFIG0       0x4F
#define ICM_REG_ACCEL_CONFIG0      0x50
#define ICM_REG_WHO_AM_I           0x75
#define ICM_WHOAMI_EXPECTED        0x47  // Expected WHO_AM_I response from ICM-42688-P

// --- IMU noise and state limits (tune as needed) ---
#define GYRO_NOISE_MARGIN     1500      // extra counts above mean gyro noise
#define ACC_NOISE_MARGIN      600000    // extra counts above mean accel^2 noise (unused now)
#define IMU_WHO_FAIL_LIMIT    10        // consecutive WHO_AM_I failures before IMU_FAIL state
#define MOTION_HIT_LIMIT      5         // samples above threshold before declaring motion
#define STILL_HIT_LIMIT       50        // samples below threshold before declaring still
#define IMU_FAIL_RECOVERY_CYCLES 400    // ~2s @200Hz; re-init after prolonged IMU_FAIL

// INTF_CONFIG0 bits (from register map; using only endian bit if needed)
#define ICM_INTF_CONFIG0_SENSOR_DATA_ENDIAN_BIT   (1u << 4)  // "SENSOR_DATA_ENDIAN" bit in INTF_CONFIG0

// PWR_MGMT0 fields: ACCEL_MODE[1:0], GYRO_MODE[3:2], IDLE[4], TEMP_DIS[5]
// 0x0F => Gyro and Accel on (Low-Noise mode), temperature sensor on

// SPI framing (per datasheet): first byte = [R/W][A6..A0] :contentReference[oaicite:3]{index=3}
#define ICM_SPI_READ   0x80
#define ICM_SPI_WRITE  0x00

// External SPI handle (HAL)
extern SPI_HandleTypeDef hspi1;

// Chip-select (CS) pin for the IMU (active LOW)
#define ICM_CS_GPIO_Port GPIOB
#define ICM_CS_Pin       GPIO_PIN_0
#ifndef IMU_CS_GPIO_Port
#define IMU_CS_GPIO_Port ICM_CS_GPIO_Port
#endif
#ifndef IMU_CS_Pin
#define IMU_CS_Pin       ICM_CS_Pin
#endif

// Convenient CS control
static inline void icm_cs_low(void)   { HAL_GPIO_WritePin(IMU_CS_GPIO_Port, IMU_CS_Pin, GPIO_PIN_RESET); }
static inline void icm_cs_high(void)  { HAL_GPIO_WritePin(IMU_CS_GPIO_Port, IMU_CS_Pin, GPIO_PIN_SET);   }

// Sensor sample container
typedef struct {
  int16_t ax, ay, az;
  int16_t gx, gy, gz;
  int16_t t;   // raw temperature
} icm_sample_t;

/* Low-level SPI operations for ICM-42688-P */
static bool icm_read(uint8_t reg, uint8_t *dst, uint16_t len) {
  uint8_t tx[1 + 64];
  uint8_t rx[1 + 64];
  if (len > 64) return false;

  tx[0] = ICM_SPI_READ | (reg & 0x7F);  // R/W bit + register address
  memset(&tx[1], 0x00, len);           // fill dummy bytes for clocking out data

  icm_cs_low();
  for (volatile int i = 0; i < 300; i++) { __NOP(); }  // small delay after CS low

  if (HAL_SPI_TransmitReceive(&hspi1, tx, rx, (uint16_t)(1 + len), 20) != HAL_OK) {
    icm_cs_high();
    return false;
  }

  for (volatile int i = 0; i < 300; i++) { __NOP(); }  // small delay before CS high
  icm_cs_high();

  // Copy received bytes (after the first dummy byte) to destination buffer
  memcpy(dst, &rx[1], len);
  return true;
}

static bool icm_write(uint8_t reg, uint8_t val) {
  uint8_t tx[2];
  uint8_t rx[2];
  tx[0] = ICM_SPI_WRITE | (reg & 0x7F);
  tx[1] = val;

  icm_cs_low();
  for (volatile int i = 0; i < 300; i++) { __NOP(); }

  bool ok = (HAL_SPI_TransmitReceive(&hspi1, tx, rx, 2, 20) == HAL_OK);

  for (volatile int i = 0; i < 300; i++) { __NOP(); }
  icm_cs_high();

  return ok;
}

// Burst-read 14 bytes starting at TEMP_DATA1 (0x1D): Temp(2) + Accel(6) + Gyro(6) :contentReference[oaicite:4]{index=4}
static bool icm_read_sample(icm_sample_t *s) {
  uint8_t buf[14];
  if (!icm_read(ICM_REG_TEMP_DATA1, buf, sizeof(buf))) {
    return false;
  }
  // Assemble bytes into 16-bit signed values (assuming big-endian sensor data)
  s->t  = (int16_t)((buf[0] << 8) | buf[1]);
  s->ax = (int16_t)((buf[2] << 8) | buf[3]);
  s->ay = (int16_t)((buf[4] << 8) | buf[5]);
  s->az = (int16_t)((buf[6] << 8) | buf[7]);
  s->gx = (int16_t)((buf[8] << 8) | buf[9]);
  s->gy = (int16_t)((buf[10] << 8) | buf[11]);
  s->gz = (int16_t)((buf[12] << 8) | buf[13]);
  return true;
}

// Validate sample data to catch SPI errors (all zeros/ones or multiple max values indicates bad read)
static bool icm_sample_plausible(const icm_sample_t *s) {
  const uint16_t *w = (const uint16_t*)s;
  bool all_zero = true, all_FFFF = true;
  for (int i = 0; i < 7; i++) {
    if (w[i] != 0x0000) all_zero = false;
    if (w[i] != 0xFFFF) all_FFFF = false;
  }
  if (all_zero || all_FFFF) return false;
  // Check if at least three axes are at INT16 max/min (could indicate SPI line stuck)
  int pinned = 0;
  const int16_t v[6] = { s->ax, s->ay, s->az, s->gx, s->gy, s->gz };
  for (int i = 0; i < 6; i++) {
    if (v[i] == 0x7FFF || v[i] == (int16_t)0x8000) pinned++;
  }
  if (pinned >= 3) return false;
  return true;
}

// ---------------- Application state machine ----------------
typedef enum {
  ST_CALIBRATING = 0,
  ST_STILL,
  ST_MOVING,
  ST_IMU_FAIL
} app_state_t;

static app_state_t g_state = ST_CALIBRATING;

// Biases and reference values for calibration
static int32_t g_gx_bias = 0, g_gy_bias = 0, g_gz_bias = 0;
static int64_t g_a_ref2 = 0;  // reference accel magnitude squared

// Thresholds for motion detection (set during calibration)
static int32_t g_gyro_thr_sumabs = 0;
static int64_t g_acc_thr_dev2   = 0;

// Filtered sensor values (IIR filter outputs)
static int32_t fgx=0, fgy=0, fgz=0;
static int32_t fax=0, fay=0, faz=0;

// Motion detection counters (debounce)
static uint16_t g_move_hits = 0;
static uint16_t g_still_hits = 0;

// Diagnostics counters
static volatile uint32_t g_bad_sample_cnt = 0;
static volatile uint32_t g_who_fail_cnt   = 0;

// ---------------- LED control helpers ----------------
static uint32_t g_led_blink_last = 0;
static bool     g_led_blink_on   = false;

static inline void led_set(bool on) {
  // Cancel any blinking when setting a solid state
  g_led_blink_last = HAL_GetTick();
  g_led_blink_on   = on;
  HAL_GPIO_WritePin(GPIOB, LED_Pin, on ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static inline void led_blink_reset(void) {
  g_led_blink_last = HAL_GetTick();
  g_led_blink_on   = false;
  HAL_GPIO_WritePin(GPIOB, LED_Pin, GPIO_PIN_RESET);
}

// Call this in a loop to blink the LED at a given frequency (non-blocking)
static void led_blink_hz(float hz) {
  if (hz <= 0.0f) {
    led_blink_reset();
    return;
  }
  uint32_t now = HAL_GetTick();
  uint32_t half_period_ms = (uint32_t)(1000.0f / (hz * 2.0f));
  if (half_period_ms < 1) half_period_ms = 1;
  if ((now - g_led_blink_last) >= half_period_ms) {
    g_led_blink_last = now;
    g_led_blink_on = !g_led_blink_on;
    HAL_GPIO_WritePin(GPIOB, LED_Pin, g_led_blink_on ? GPIO_PIN_SET : GPIO_PIN_RESET);
  }
}

// Integer absolute value helpers
static inline int32_t iabs32(int32_t x) { return (x < 0) ? -x : x; }
static inline int64_t iabs64(int64_t x) { return (x < 0) ? -x : x; }

// Simple first-order IIR filter: y += (x - y) / N
static inline int32_t iir1(int32_t y, int32_t x, int32_t N) {
  return y + (x - y) / N;
}

// WHO_AM_I check helper
static bool icm_check_whoami(uint8_t *who) {
  uint8_t val = 0;
  if (!icm_read(ICM_REG_WHO_AM_I, &val, 1)) {
    return false;  // SPI read failed
  }
  if (who) *who = val;
  return (val == ICM_WHOAMI_EXPECTED);
}

// Basic IMU init: checks WHO_AM_I and wakes sensors
static bool icm_init_basic(void) {
  // Try multiple attempts to read WHO_AM_I
  for (int attempt = 0; attempt < 5; attempt++) {
    uint8_t who = 0;
    if (icm_check_whoami(&who)) {
      // Found correct device ID
      (void)icm_write(ICM_REG_PWR_MGMT0, 0x0F);  // Power on accelerometer and gyro
      HAL_Delay(10);
      return true;
    }
    HAL_Delay(2);
  }
  // If initial attempts failed, perform a soft reset and try again
  (void)icm_write(ICM_REG_DEVICE_CONFIG, 0x01);  // trigger device soft reset
  HAL_Delay(50);
  for (int attempt = 0; attempt < 5; attempt++) {
    uint8_t who = 0;
    if (icm_check_whoami(&who)) {
      (void)icm_write(ICM_REG_PWR_MGMT0, 0x0F);
      HAL_Delay(10);
      return true;
    }
    HAL_Delay(2);
  }
  return false;  // IMU not responding
}

// Main IMU task, runs ~200 Hz (called in main loop)
static void imu_task_200hz(void) {
  static uint32_t last_ms = 0;
  uint32_t now = HAL_GetTick();
  if ((now - last_ms) < 5) return;  // ~200Hz loop guard (5ms interval)
  last_ms = now;

  // Periodically check WHO_AM_I to detect if IMU goes offline
  static uint8_t who_fail_count = 0;
  uint8_t who_val = 0;
  bool who_ok = icm_check_whoami(&who_val);
  if (!who_ok) {
    g_who_fail_cnt++;
    if (++who_fail_count >= IMU_WHO_FAIL_LIMIT) {
      g_state = ST_IMU_FAIL;
    }
  } else {
    // IMU is responding
    who_fail_count = 0;
    if (g_state == ST_IMU_FAIL) {
      // If we were in fail state, recover to calibrating
      g_state = ST_CALIBRATING;
    }
  }

  // Handle IMU failure state with auto-recovery
  static uint16_t imu_fail_timer = 0;
  if (g_state == ST_IMU_FAIL) {
    imu_fail_timer++;
    led_blink_hz(1.5f);  // blink LED at 1.5 Hz to indicate IMU failure
    if (imu_fail_timer >= IMU_FAIL_RECOVERY_CYCLES) {
      // Try re-initializing IMU after ~2 seconds of failure
      if (icm_init_basic()) {
        g_state = ST_CALIBRATING;
        g_move_hits = 0;
        g_still_hits = 0;
      }
      imu_fail_timer = 0;
    }
    return;  // stay in fail state until recovered
  } else {
    imu_fail_timer = 0;
  }

  // If we reach here, IMU is in a good state (ST_CALIBRATING, ST_STILL, or ST_MOVING)
  icm_sample_t sample;
  static uint16_t bad_sample_streak = 0;
  if (!icm_read_sample(&sample)) {
    // Failed to read a sample (SPI error)
    g_bad_sample_cnt++;
    if (++bad_sample_streak > 50) {
      g_state = ST_IMU_FAIL;
      bad_sample_streak = 0;
    }
    return;
  }
  if (!icm_sample_plausible(&sample)) {
    // Read data, but it looks invalid/unrealistic
    g_bad_sample_cnt++;
    if (++bad_sample_streak > 50) {
      g_state = ST_IMU_FAIL;
      bad_sample_streak = 0;
    }
    return;
  }
  bad_sample_streak = 0;  // good sample

  // Apply simple filtering to raw data
  fax = iir1(fax, sample.ax, 8);
  fay = iir1(fay, sample.ay, 8);
  faz = iir1(faz, sample.az, 8);
  fgx = iir1(fgx, sample.gx, 8);
  fgy = iir1(fgy, sample.gy, 8);
  fgz = iir1(fgz, sample.gz, 8);

  // State machine for motion detection
  if (g_state == ST_CALIBRATING) {
    // Blink LED fast during calibration
    led_blink_hz(6.0f);

    // Collect data for 1 second (~200 samples)
    static uint16_t n = 0;
    static int64_t sum_ax2 = 0, sum_ay2 = 0, sum_az2 = 0;
    static int64_t sum_gx = 0, sum_gy = 0, sum_gz = 0;
    static int64_t sum_g_sumabs = 0;
    static int64_t sum_a2 = 0, sum_a2_dev = 0;

    // Accumulate filtered values
    int32_t gx = fgx, gy = fgy, gz = fgz;
    int32_t ax = fax, ay = fay, az = faz;
    int32_t g_sumabs = iabs32(gx) + iabs32(gy) + iabs32(gz);
    int64_t a2 = (int64_t)ax*ax + (int64_t)ay*ay + (int64_t)az*az;

    sum_gx += gx; sum_gy += gy; sum_gz += gz;
    sum_g_sumabs += g_sumabs;
    sum_a2 += a2;
    if (n > 20) {  // ignore first 20 samples for accel deviation calculation
      int64_t a_ref2_temp = sum_a2 / (int64_t)(n + 1);
      sum_a2_dev += iabs64(a2 - a_ref2_temp);
    }

    n++;
    if (n >= 200) {
      // Calculate biases and thresholds after 1 sec
      g_gx_bias = (int32_t)(sum_gx / n);
      g_gy_bias = (int32_t)(sum_gy / n);
      g_gz_bias = (int32_t)(sum_gz / n);
      g_a_ref2  = (int64_t)(sum_a2 / n);

      int32_t g_mean = (int32_t)(sum_g_sumabs / n);
      int64_t a2_dev_mean = (n > 20) ? (sum_a2_dev / (int64_t)(n - 20)) : 0;

      // Set dynamic thresholds with some margins
      g_gyro_thr_sumabs = g_mean + 800;
      g_acc_thr_dev2    = a2_dev_mean + 300000;

      // Reset motion counters
      g_move_hits = 0;
      g_still_hits = 0;
      g_state = ST_STILL;   // assume device is still after calibration
      led_set(false);       // LED off to indicate still

      // Reset accumulators for next calibration if needed
      n = 0;
      sum_gx = sum_gy = sum_gz = 0;
      sum_g_sumabs = 0;
      sum_a2 = sum_a2_dev = 0;
    }
    return;
  }

  // After calibration, decide between STILL and MOVING states
  int32_t gx = fgx - g_gx_bias;
  int32_t gy = fgy - g_gy_bias;
  int32_t gz = fgz - g_gz_bias;
  int32_t g_sumabs = iabs32(gx) + iabs32(gy) + iabs32(gz);
  bool motion_now = (g_sumabs > g_gyro_thr_sumabs);

  if (g_state == ST_STILL) {
    led_set(false);  // LED off when stationary
    if (motion_now) {
      if (++g_move_hits >= MOTION_HIT_LIMIT) {
        // Detected movement
        g_state = ST_MOVING;
        g_move_hits = 0;
        g_still_hits = 0;
        led_set(true);   // LED solid ON when moving
      }
    } else {
      g_move_hits = 0;   // clear counter if no movement
    }
  }
  else if (g_state == ST_MOVING) {
    led_set(true);  // LED on when moving
    if (!motion_now) {
      if (++g_still_hits >= STILL_HIT_LIMIT) {
        // Movement stopped
        g_state = ST_STILL;
        g_still_hits = 0;
        g_move_hits = 0;
        led_set(false);  // LED OFF when back to still
      }
    } else {
      g_still_hits = 0;
    }
  }
  else {
    // Fallback (should not happen normally)
    g_state = ST_CALIBRATING;
    g_move_hits = 0;
    g_still_hits = 0;
    led_blink_reset();
  }
}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// (All IMU & LED logic is implemented above in USER CODE section)
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();  // Reset peripherals and init Flash and Systick

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_SPI1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();

  /* USER CODE BEGIN 2 */
  // Ensure IMU CS is high (deselected) before starting
  HAL_GPIO_WritePin(IMU_CS_GPIO_Port, IMU_CS_Pin, GPIO_PIN_SET);
  HAL_Delay(50);  // wait 50ms for IMU to power-up and be ready

  // Visual boot indicator: blink LED quickly 4 times
  for (int i = 0; i < 4; i++) {
    HAL_GPIO_TogglePin(GPIOB, LED_Pin);
    HAL_Delay(120);
  }
  led_set(false);

  // Initialize IMU (if this fails, we will blink error and not proceed)
  if (!icm_init_basic()) {
    // IMU did not respond – blink LED at 1.5 Hz indefinitely to indicate error
    while (1) {
      led_blink_hz(1.5f);
    }
  }

  g_state = ST_CALIBRATING;  // start in calibrating state

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    imu_task_200hz();  // run IMU state machine tasks
    // (Add other application code here if needed)
    /* USER CODE END 3 */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void) {
  // ... (System clock configuration generated by CubeMX remains unchanged)
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
    Error_Handler();
  }
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  */
static void MX_ADC1_Init(void) {
  // ... (ADC initialization as generated by CubeMX)
  ADC_ChannelConfTypeDef sConfig = {0};
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK) {
    Error_Handler();
  }
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  */
static void MX_SPI1_Init(void) {
  /* USER CODE BEGIN SPI1_Init 0 */
  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */
  // Enable SPI1 and GPIOA clocks, and configure SPI pins
  __HAL_RCC_SPI1_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;    // SCK, MISO, MOSI
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  /* USER CODE END SPI1_Init 1 */

  /* SPI1 parameter configuration */
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;  // ~1.3 MHz (can increase after stable)
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */
  // (No further SPI init code needed)
  /* USER CODE END SPI1_Init 2 */
}

/**
  * @brief TIM2 Initialization Function
  */
static void MX_TIM2_Init(void) {
  // ... (TIM2 base initialization as generated by CubeMX)
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 83;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK) {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function
  */
static void MX_TIM3_Init(void) {
  // ... (TIM3 base initialization)
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 8399;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK) {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief TIM4 Initialization Function
  */
static void MX_TIM4_Init(void) {
  // ... (TIM4 base initialization)
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 83;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 2499;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK) {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void) {
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  // Enable GPIO port clocks for A and B
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  // Configure IMU CS pin (PB0) and LED pin (PBx) as outputs
  HAL_GPIO_WritePin(IMU_CS_GPIO_Port, IMU_CS_Pin, GPIO_PIN_SET);    // CS high (not selected)
  HAL_GPIO_WritePin(GPIOB, LED_Pin, GPIO_PIN_RESET);                // LED off

  GPIO_InitStruct.Pin = IMU_CS_Pin | LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // (Any other GPIO init, e.g., Buzzer, would go here if configured)
}

/* USER CODE BEGIN 4 */
/* (Additional user code can go here, if needed) */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of an error.
  */
void Error_Handler(void) {
  __disable_irq();
  // Flash the LED rapidly to indicate a severe error (infinite loop)
  while (1) {
    HAL_GPIO_TogglePin(GPIOB, LED_Pin);
    HAL_Delay(80);
  }
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the source file and line number where assert_param error has occurred.
  */
void assert_failed(uint8_t *file, uint32_t line) {
  /* User can add custom implementation to report file name and line number */
}
#endif /* USE_FULL_ASSERT */
